default_production_dict={
    "layer_height":2.5
}

default_brick_geometry_dict={
    "height_body":170.,
    "height_pin" :350.,
    "start_height":1.4,
    "brick_length":350.,
    "brick_width":250.,
    "pin_spacing":250.
}