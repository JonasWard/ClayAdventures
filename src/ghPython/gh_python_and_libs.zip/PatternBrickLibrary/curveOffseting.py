# scripts that create continous offsets for different types of curves
import Rhino.Geometry as rg
from copy import deepcopy as dc



    

